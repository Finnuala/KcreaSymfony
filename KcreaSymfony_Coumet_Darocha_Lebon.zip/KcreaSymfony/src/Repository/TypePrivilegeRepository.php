<?php

namespace App\Repository;

use App\Entity\TypePrivilege;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Symfony\Bridge\Doctrine\RegistryInterface;

/**
 * @method TypePrivilege|null find($id, $lockMode = null, $lockVersion = null)
 * @method TypePrivilege|null findOneBy(array $criteria, array $orderBy = null)
 * @method TypePrivilege[]    findAll()
 * @method TypePrivilege[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class TypePrivilegeRepository extends ServiceEntityRepository
{
    public function __construct(RegistryInterface $registry)
    {
        parent::__construct($registry, TypePrivilege::class);
    }

//    /**
//     * @return TypePrivilege[] Returns an array of TypePrivilege objects
//     */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('t')
            ->andWhere('t.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('t.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?TypePrivilege
    {
        return $this->createQueryBuilder('t')
            ->andWhere('t.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}
