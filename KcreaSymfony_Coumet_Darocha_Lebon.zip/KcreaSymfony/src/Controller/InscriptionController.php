<?php

namespace App\Controller;

use App\Entity\Mediatheque;
use App\Entity\Utilisateur;
use App\Form\UtilisateurType;
use Symfony\Component\HttpFoundation\Session\SessionInterface;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class InscriptionController extends Controller
{
    /**
     * @Route("/inscription", name="inscription")
     */
    public function inscription(\Symfony\Component\HttpFoundation\Request $request, SessionInterface $session)
    {
        $form = $this->createForm(UtilisateurType::class);

        $form->handleRequest($request);
//
        if ($form->isSubmitted() && $form->isValid()) {

            $mediatheque = new Mediatheque();
            $mediatheque->setNom($form["mediatheque"]->getData());
            $utilisateur = new Utilisateur();
            $mediatheque = new Mediatheque();
            $mediatheque->setNom($form["mediatheque"]->getData());
            $utilisateur = $form->getData();
            $utilisateur->setMediatheque($mediatheque);
            $mediatheque->setUtilisateur($utilisateur);
//
            if($utilisateur != null) {
                echo $utilisateur->getPseudo();
                $entityManager = $this->getDoctrine()->getManager();
                $entityManager->persist($utilisateur);
                $entityManager->flush();


                $session->set('utilisateur', $utilisateur);
                return $this->redirectToRoute('recherche_film', array(
                ));
            }
            else {

                return $this->render('inscription/index.html.twig', array(
                    'form' => $form->createView(),
                ));
            }
        }
        return $this->render('inscription/index.html.twig', array(
            'form' => $form->createView(),
        ));
    }
}
