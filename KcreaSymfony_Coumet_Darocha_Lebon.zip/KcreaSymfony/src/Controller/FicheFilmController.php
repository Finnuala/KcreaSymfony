<?php

namespace App\Controller;

use App\Entity\Acteur;
use App\Entity\Film;
use App\Entity\GenreFilm;
use App\Entity\Realisateur;
use App\Form\AjouterFilmType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Session\SessionInterface;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Validator\Constraints\DateTime;
use Unirest;

class FicheFilmController extends Controller
{
    /**
     * @Route("/fiche/film/{film}", name="fiche_film")
     */
    public function afficherFiche($film, Request $request, SessionInterface $session)
    {

        $headers = array('Accept' => 'application/json');
        $query = array('i' => $film, 'apikey' => '4d2d028a&');


        $response = Unirest\Request::get('http://www.omdbapi.com/',$headers,$query);
        $obj = json_decode($response->raw_body);


        $form = $this->createForm(AjouterFilmType::class);

        $form->handleRequest($request);
//
        if ($form->isSubmitted() && $form->isValid()) {
            $utilisateurSession = $session->get('utilisateur');
            $entityManager = $this->getDoctrine()->getRepository('App:Utilisateur');
            $utilisateur = $entityManager->find($utilisateurSession->getId());
            $mediatheque = $utilisateur->getMediatheque();
            //print_r(array($obj->Actors));
            $filmAjoute = new Film();
            $filmAjoute->setTitre($obj->Title);
            $filmAjoute->setDescription($obj->Plot);
            $time = strtotime($obj->Released);
            $dateSortie = date('Y-m-d',$time);
            $filmAjoute->setDateSortie($dateSortie);
            $filmAjoute->setAffiche($obj->Poster);

            $acteurs = explode(",", $obj->Actors);
            $realisateurs = explode(",", $obj->Director);
            $genres = explode(",", $obj->Genre);


            foreach ($genres as $genre)
            {
                $genreAjoute = new GenreFilm();
                $genreAjoute->setLibelle($genre);
                $filmAjoute->addGenre($genreAjoute);
                $genreAjoute->addFilm($filmAjoute);
            }

            foreach ($acteurs as $acteur)
            {
                $acteurAjoute = new Acteur();
                $acteurAjoute->setNom($acteur);
                $filmAjoute->addActeur($acteurAjoute);
                $acteurAjoute->addFilm($filmAjoute);
            }

            foreach ($realisateurs as $realisateur)
            {
                $realisateurAjoute = new Realisateur();
                $realisateurAjoute->setNom($realisateur);
                $filmAjoute->addRealisateur($realisateurAjoute);
                $realisateurAjoute->addFilm($filmAjoute);
            }



            $mediatheque->addFilm($filmAjoute);
            //PERSIST CA MAIS AVANT FAIRE ATTENTION AUX CASCADES
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($mediatheque);
            $entityManager->flush();

            return $this->redirectToRoute('mediatheque');
        }

        return $this->render('fiche_film/index.html.twig', [
            'form' => $form->createView(),
            'film' => $obj,
        ]);
    }
}
