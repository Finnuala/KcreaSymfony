<?php

namespace App\Controller;

use App\Entity\Utilisateur;
use App\Form\ConnexionType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\HttpFoundation\Session\SessionInterface;

class ConnexionController extends Controller
{

    public function connexion(\Symfony\Component\HttpFoundation\Request $request, SessionInterface $session)
    {

        $form = $this->createForm(ConnexionType::class);

        $form->handleRequest($request);
//
      if ($form->isSubmitted() && $form->isValid()) {
          // $form->getData() holds the submitted values
          // but, the original `$task` variable has also been updated
          $connexion = $form->getData();

//            // ... perform some action, such as saving the task to the database
//            // for example, if Task is a Doctrine entity, save it!
          $entityManager = $this->getDoctrine()->getRepository('App:Utilisateur');
          $utilisateur = $entityManager->findOneBySomeField($connexion["email"], $connexion["password"]);
          if($utilisateur != null) {
              echo $utilisateur->getPseudo();
              $session->set('utilisateur', $utilisateur);
              return $this->redirectToRoute('recherche_film', array(
                  'utilisateur' => $utilisateur,
              ));
          }
          else {
              return $this->render('connexion/index.html.twig', array(
                  'form' => $form->createView(),
              ));
          }
      }
        return $this->render('connexion/index.html.twig', array(
            'form' => $form->createView(),
        ));
    }
}
