<?php

namespace App\Controller;

use App\Form\RechercheType;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Session\SessionInterface;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Unirest;

class RechercheFilmController extends Controller
{
    /**
     * @Route("/recherche/film", name="recherche_film")
     */
    public function recherche(Request $request, SessionInterface $session)
    {
        $utilisateurSession = $session->get('utilisateur');
        print_r($utilisateurSession->getEmail());


        $form = $this->createForm(RechercheType::class);

        $form->handleRequest($request);


        if ($form->isSubmitted() && $form->isValid()) {
            $searchQuery = $form['recherche']->getData();
            $headers = array('Accept' => 'application/json');
            $query = array('s' => $searchQuery, 'apikey' => '4d2d028a&');


            $response = Unirest\Request::get('http://www.omdbapi.com/',$headers,$query);

            $obj = json_decode($response->raw_body);

            return $this->render('recherche_film/index.html.twig', [
                'form' => $form->createView(),
                'listResultFilms' => $obj->{'Search'},
                ]);

        }

        return $this->render('recherche_film/index.html.twig', [
            'form' => $form->createView(),
        ]);
    }
}
