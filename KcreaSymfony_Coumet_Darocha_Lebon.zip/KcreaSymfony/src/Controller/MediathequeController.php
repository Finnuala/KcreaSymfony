<?php

namespace App\Controller;

use App\Form\ModifierNoteType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Session\SessionInterface;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class MediathequeController extends Controller
{
    /**
     * @Route("/mediatheque", name="mediatheque")
     */
    public function index(Request $request, SessionInterface $session)
    {
        //$form = $this->createForm(ModifierNoteType::class);

        //$form->handleRequest($request);

        $utilisateurSession = $session->get('utilisateur');
        $entityManager = $this->getDoctrine()->getRepository('App:Utilisateur');
        $utilisateur = $entityManager->find($utilisateurSession->getId());
        $mediatheque = $utilisateur->getMediatheque();


        return $this->render('mediatheque/index.html.twig', [
            //'form' => $form->createView(),
            'mediatheque' => $mediatheque,
            'controller_name' => 'MediathequeController',
        ]);
    }
}
