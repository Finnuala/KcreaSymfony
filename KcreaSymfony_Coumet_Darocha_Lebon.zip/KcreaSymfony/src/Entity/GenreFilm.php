<?php

namespace App\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\GenreFilmRepository")
 */
class GenreFilm
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $libelle;

    /**
     * GenreFilm constructor.
     * @param $films
     */
    public function __construct()
    {
        $this->films= new ArrayCollection();
    }

    /**
     * @return mixed
     */
    public function getFilms()
    {
        return $this->films;
    }

    /**
     * @param mixed $films
     */
    public function setFilms($films): void
    {
        $this->films = $films;
    }

    public function addFilm($film): void
    {
        $this->films->add($film);
    }

    /**
     * @ORM\ManyToMany(targetEntity="Film", cascade={"persist"}, inversedBy="genres")
     */
    private $films;

    public function getId()
    {
        return $this->id;
    }

    public function getLibelle(): ?string
    {
        return $this->libelle;
    }

    public function setLibelle(string $libelle): self
    {
        $this->libelle = $libelle;

        return $this;
    }
}
