<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\Collection;
use Doctrine\Common\Collections\ArrayCollection;
use App\Entity\Film;

/**
 * @ORM\Entity(repositoryClass="App\Repository\ActeurRepository")
 */
class Acteur extends Personne
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\ManyToMany(targetEntity="Film", cascade={"persist"}, inversedBy="acteurs")
     */
    private $films;

    /**
     * @return mixed
     */
    public function getFilms()
    {
        return $this->films;
    }

    /**
     * @param mixed $films
     */
    public function setFilms($films): void
    {
        $this->films = $films;
    }

    public function addFilm($film): void
    {
        $this->films->add($film);
    }

    public function __construct()
    {
        $this->films = new ArrayCollection();
    }

    public function getId()
    {
        return $this->id;
    }

}
