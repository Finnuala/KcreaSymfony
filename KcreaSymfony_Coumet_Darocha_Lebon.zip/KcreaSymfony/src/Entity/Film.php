<?php

namespace App\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;
use App\Entity\Acteur;
use function Sodium\add;

/**
 * @ORM\Entity(repositoryClass="App\Repository\FilmRepository")
 */
class Film
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $titre;

    /**
     * @ORM\Column(type="text")
     */
    private $description;

    /**
     * @ORM\Column(type="string")
     */
    private $dateSortie;

    /**
     * @ORM\ManyToMany(targetEntity="Mediatheque", cascade={"persist"}, mappedBy="films")
     */
    private $mediatheques;

    /**
     * @ORM\ManyToMany(targetEntity="Acteur",cascade={"persist"}, mappedBy="films")
     */
    private $acteurs;

    /**
     * @ORM\ManyToMany(targetEntity="Realisateur",cascade={"persist"}, mappedBy="films")
     */
    private $realisateurs;

    /**
     * @ORM\ManyToMany(targetEntity="GenreFilm", cascade={"persist"}, mappedBy="films")
     */
    private $genres;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $affiche;

    /**
     * Film constructor.
     * @param $mediatheques
     * @param $acteurs
     * @param $realisateurs
     * @param $genres
     */
    public function __construct()
    {
        $this->mediatheques = new ArrayCollection();
        $this->acteurs = new ArrayCollection();
        $this->realisateurs = new ArrayCollection();
        $this->genres = new ArrayCollection();
    }

    public function getId()
    {
        return $this->id;
    }

    public function getTitre(): ?string
    {
        return $this->titre;
    }

    public function setTitre(string $titre): self
    {
        $this->titre = $titre;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(string $description): self
    {
        $this->description = $description;

        return $this;
    }

    public function getDateSortie()
    {
        return $this->dateSortie;
    }

    public function setDateSortie($dateSortie)
    {
        $this->dateSortie = $dateSortie;
    }

    /**
     * @return mixed
     */
    public function getMediatheques()
    {
        return $this->mediatheques;
    }

    /**
     * @param mixed $mediatheques
     */
    public function setMediatheques($mediatheques): void
    {
        $this->mediatheques = $mediatheques;
    }

    public function addMediatheque($mediatheque): void
    {
        $this->mediatheques->add($mediatheque);
    }

    /**
     * @return mixed
     */
    public function getActeurs()
    {
        return $this->acteurs;
    }

    /**
     * @param mixed $acteurs
     */
    public function setActeurs($acteurs): void
    {
        $this->acteurs = $acteurs;
    }

    public function addActeur($acteur) : void
    {
        $this->acteurs->add($acteur);
    }
    /**
     * @return mixed
     */
    public function getRealisateurs()
    {
        return $this->realisateurs;
    }

    /**
     * @param mixed $realisateurs
     */
    public function setRealisateurs($realisateurs): void
    {
        $this->realisateurs = $realisateurs;
    }

    public function addRealisateur($realisateur) : void
    {
        $this->realisateurs->add($realisateur);
    }

    /**
     * @return mixed
     */
    public function getGenres()
    {
        return $this->genres;
    }

    /**
     * @param mixed $genres
     */
    public function setGenres($genres): void
    {
        $this->genres = $genres;
    }

    public function addGenre($genre) : void
    {
        $this->genres->add($genre);
    }

    public function getAffiche(): ?string
    {
        return $this->affiche;
    }

    public function setAffiche(?string $affiche)
    {
        $this->affiche = $affiche;
    }

}
