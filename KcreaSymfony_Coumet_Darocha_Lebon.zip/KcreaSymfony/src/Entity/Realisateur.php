<?php

namespace App\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\RealisateurRepository")
 */
class Realisateur extends Personne
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * Realisateur constructor.
     * @param $films
     */
    public function __construct()
    {
        $this->films = new ArrayCollection();
    }

    /**
     * @return mixed
     */
    public function getFilms()
    {
        return $this->films;
    }

    /**
     * @param mixed $films
     */
    public function setFilms($films): void
    {
        $this->films = $films;
    }

    public function addFilm($film): void
    {
        $this->films->add($film);
    }

    /**
     * @ORM\ManyToMany(targetEntity="Film", cascade={"persist"}, inversedBy="realisateurs")
     */
    private $films;

    public function getId()
    {
        return $this->id;
    }
}
